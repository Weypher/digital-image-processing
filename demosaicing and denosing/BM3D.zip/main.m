filename_noisy = "C:\Users\Alienware\Documents\MATLAB\HW1_images\Corn_noisy.raw";
filename_noisefree = "C:\Users\Alienware\Documents\MATLAB\HW1_images\Corn_gray.raw";
noisy = readraw(filename_noisy);
noisefree = readraw(filename_noisefree);
noisy_Anscombe = Anscombe_forward(noisy);

minimum = min(min(noisy_Anscombe));
maximum = max(max(noisy_Anscombe));

z = (noisy_Anscombe - minimum) / (maximum - minimum);
%for i = 1 : 20
i = 20;
sigma = i;
[PSNR, y_est] = BM3D(1, z, sigma);
noisy_est = y_est * (maximum - minimum) + minimum;

result = Anscombe_reverse_biased(noisy_est);

filename_save = "C:\Users\Alienware\Documents\MATLAB\HW1_images\Corn_noisy_BM3D_"+ num2str(sigma) +".raw";
count = writeraw(result, filename_save);
%end

peaksnr = psnr1(result, noisefree);

filtered = readraw(filename_save);